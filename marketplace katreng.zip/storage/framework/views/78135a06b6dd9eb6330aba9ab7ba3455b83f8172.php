<?php
    $memberName = $member->nm_member ?? 'Pengguna';
    $icons = ['dashboard' => '⌂', 'barang' => '▦', 'kategori' => '◇', 'penjualan' => '↗'];
    $descriptions = [
        'dashboard' => 'Pantau kondisi toko Anda dalam satu tampilan.',
        'barang' => 'Lihat daftar produk dan informasi stok.',
        'kategori' => 'Lihat kategori dan jumlah produk di setiap kategori.',
        'penjualan' => 'Periksa riwayat transaksi penjualan.',
    ];
    $subject = ['barang' => 'Barang', 'kategori' => 'Kategori'][$page] ?? '';
    $recordId = $page === 'barang' ? 'id' : 'id_kategori';
    $getValue = static fn (string $key, mixed $default = '') => old($key, data_get($editRecord, $key, $default));
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e($pages[$page]); ?> - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/dashboard.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="app-shell">
        <aside class="sidebar">
            <a class="brand" href="<?php echo e(route('merchant.dashboard')); ?>">
                <span class="brand-icon">MK</span>
                <span><strong><?php echo e(config('app.name')); ?></strong><small>Manajemen toko</small></span>
            </a>

            <p class="nav-caption">MENU UTAMA</p>
            <nav class="main-nav" aria-label="Menu utama">
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <a class="nav-link<?php echo e($page === $key ? ' active' : ''); ?>"
                       href="<?php echo e(route('merchant.dashboard', $key === 'dashboard' ? [] : ['page' => $key])); ?>"
                       <?php if($page === $key): ?> aria-current="page" <?php endif; ?>>
                        <span class="nav-icon" aria-hidden="true"><?php echo e($icons[$key]); ?></span>
                        <?php echo e($label); ?>

                    </a>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <a class="nav-link" href="<?php echo e(route('merchant.orders.index')); ?>">
                    <span class="nav-icon" aria-hidden="true">▤</span> Pesanan katering
                </a>
                <a class="nav-link<?php echo e(request()->routeIs('merchant.profile.*') ? ' active' : ''); ?>"
                   href="<?php echo e(route('merchant.profile.edit')); ?>">
                    <span class="nav-icon" aria-hidden="true">♙</span> Profil katering
                </a>
            </nav>

            <div class="sidebar-bottom">
                <div class="profile">
                    <span class="avatar"><?php echo e(mb_strtoupper(mb_substr($memberName, 0, 1))); ?></span>
                    <span class="profile-copy"><strong><?php echo e($memberName); ?></strong><small>Katering Merchant</small></span>
                </div>
                <form method="POST" action="<?php echo e(route('logout')); ?>">
                    <?php echo csrf_field(); ?>
                    <button class="logout-link" type="submit"><span aria-hidden="true">↪</span> Keluar</button>
                </form>
            </div>
        </aside>

        <div class="main-area">
            <header class="topbar">
                <div>
                    <p class="topbar-label">MARKETPLACE KATERING <span>/</span> <?php echo e($pages[$page]); ?></p>
                    <p class="topbar-date"><?php echo e(now()->locale('id')->translatedFormat('l, j F Y')); ?></p>
                </div>
            </header>

            <main class="content">
                <section class="page-heading">
                    <div>
                        <p class="eyebrow"><?php echo e($page === 'dashboard' ? 'RINGKASAN TOKO' : 'MANAJEMEN TOKO'); ?></p>
                        <h1><?php echo e($page === 'dashboard' ? 'Selamat datang, ' . $memberName : $pages[$page]); ?></h1>
                        <p class="heading-description"><?php echo e($descriptions[$page]); ?></p>
                    </div>
                    <?php if($page !== 'dashboard'): ?>
                        <div class="heading-actions">
                            <?php if(in_array($page, ['barang', 'kategori'], true)): ?>
                                <a class="button button-primary" href="<?php echo e(route('merchant.dashboard', ['page' => $page, 'action' => 'create'])); ?>">
                                    <span aria-hidden="true">＋</span> Tambah <?php echo e($subject); ?>

                                </a>
                            <?php endif; ?>
                            <?php if($page === 'penjualan'): ?>
                                <a class="button button-plain" href="<?php echo e(route('merchant.reports.excel')); ?>">Ekspor CSV</a>
                                <a class="button button-plain" href="<?php echo e(route('merchant.reports.print')); ?>" target="_blank" rel="noopener">Cetak / PDF</a>
                            <?php endif; ?>
                            <form class="search-form" method="GET" action="<?php echo e(route('merchant.dashboard')); ?>">
                                <input type="hidden" name="page" value="<?php echo e($page); ?>">
                                <label class="visually-hidden" for="dashboard-search">Cari data</label>
                                <input id="dashboard-search" name="q" type="search" placeholder="Cari data..." value="<?php echo e($search); ?>">
                                <button type="submit" aria-label="Cari">⌕</button>
                            </form>
                        </div>
                    <?php endif; ?>
                </section>

                <?php if(session('status')): ?>
                    <div class="notice notice-success" role="status"><?php echo e(session('status')); ?></div>
                <?php endif; ?>
                <?php if(session('error')): ?>
                    <div class="notice notice-error" role="alert"><?php echo e(session('error')); ?></div>
                <?php endif; ?>
                <?php if($errors->any()): ?>
                    <div class="notice notice-error" role="alert"><?php echo e($errors->first()); ?></div>
                <?php endif; ?>

                <?php if($page === 'dashboard'): ?>
                    <?php if($incompleteMenuCount > 0): ?>
                        <div class="notice notice-warning" role="status">
                            <?php echo e(number_format($incompleteMenuCount)); ?> menu belum tersedia untuk kantor. Atur stok menu agar pemesanan dapat dilakukan.
                            <a href="<?php echo e(route('merchant.dashboard', ['page' => 'barang'])); ?>">Lengkapi data menu</a>.
                        </div>
                    <?php endif; ?>
                    <section class="stats-grid" aria-label="Statistik toko">
                        <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a class="stat-card" href="<?php echo e($stat['page'] === 'pesanan' ? route('merchant.orders.index') : route('merchant.dashboard', ['page' => $stat['page']])); ?>">
                                <span class="stat-icon"><?php echo e($stat['icon']); ?></span>
                                <span class="stat-label"><?php echo e($stat['label']); ?></span>
                                <strong><?php echo e(number_format($stat['value'])); ?></strong>
                                <span class="stat-foot">Lihat detail <span aria-hidden="true">→</span></span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </section>

                    <section class="insight-grid">
                        <div class="insight-card revenue-card">
                            <div>
                                <p class="card-kicker">TOTAL PESANAN DITERIMA</p>
                                <h2>Rp <?php echo e(number_format($revenue, 0, ',', '.')); ?></h2>
                                <p class="muted">Nilai dari pesanan yang diterima</p>
                            </div>
                            <span class="revenue-icon" aria-hidden="true">↗</span>
                        </div>
                        <a class="insight-card stock-card" href="<?php echo e(route('merchant.dashboard', ['page' => 'barang'])); ?>">
                            <span class="stock-icon" aria-hidden="true">!</span>
                            <span><strong><?php echo e(number_format($lowStock)); ?> menu</strong><small>Stok menipis (5 atau kurang)</small></span>
                            <span class="arrow" aria-hidden="true">→</span>
                        </a>
                    </section>

                    <section class="panel">
                        <div class="panel-heading">
                            <div>
                                <h2>Pesanan terbaru</h2>
                                <p>Permintaan katering terbaru dari kantor</p>
                            </div>
                            <a href="<?php echo e(route('merchant.orders.index')); ?>">Lihat semua <span aria-hidden="true">→</span></a>
                        </div>
                        <?php if($rows->isNotEmpty()): ?>
                            <div class="table-wrap">
                                <table>
                                    <thead>
                                        <tr>
                                            <th>Invoice</th>
                                            <th>Kantor</th>
                                            <th>Tanggal kirim</th>
                                            <th>Total</th>
                                            <th>Status</th>
                                            <th></th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <td class="primary-cell"><?php echo e($row->invoice_number); ?></td>
                                                <td><?php echo e($row->customer_name); ?></td>
                                                <td><?php echo e(\Illuminate\Support\Carbon::parse($row->delivery_date)->locale('id')->translatedFormat('j F Y')); ?></td>
                                                <td>Rp <?php echo e(number_format((float) $row->subtotal, 0, ',', '.')); ?></td>
                                                <td>
                                                    <?php echo e($row->status === 'pending' ? 'Menunggu' : ($row->status === 'accepted' ? 'Diterima' : 'Ditolak')); ?>

                                                </td>
                                                <td>
                                                    <a class="table-action table-action-edit"
                                                       href="<?php echo e(route('merchant.orders.invoice', $row->id)); ?>">Invoice</a>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state">Belum ada pesanan katering.</div>
                        <?php endif; ?>
                    </section>
                <?php else: ?>
                    <?php if($showForm): ?>
                        <section class="panel form-panel">
                            <div class="panel-heading">
                                <div>
                                    <h2><?php echo e($formAction === 'edit' ? 'Edit' : 'Tambah'); ?> <?php echo e($subject); ?></h2>
                                    <p>Isi data berikut lalu simpan perubahan.</p>
                                </div>
                            </div>
                            <form class="manage-form" method="POST" enctype="multipart/form-data" action="<?php echo e(route('merchant.manage')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="page" value="<?php echo e($page); ?>">
                                <input type="hidden" name="action" value="<?php echo e($formAction === 'edit' ? 'update' : 'create'); ?>">
                                <?php if($formAction === 'edit'): ?>
                                    <input type="hidden" name="id" value="<?php echo e(data_get($editRecord, $recordId)); ?>">
                                <?php endif; ?>

                                <?php if($page === 'barang'): ?>
                                    <div class="form-grid">
                                        <label>Kode menu
                                            <input name="id_barang" maxlength="255" value="<?php echo e($getValue('id_barang')); ?>" required>
                                        </label>
                                        <label>Nama menu masakan
                                            <input name="nama_barang" maxlength="255" value="<?php echo e($getValue('nama_barang')); ?>" required>
                                        </label>
                                        <label class="field-wide">Deskripsi menu
                                            <textarea name="description" rows="3" maxlength="2000" required><?php echo e($getValue('description')); ?></textarea>
                                        </label>
                                        <label>Kategori
                                            <select name="id_kategori" required>
                                                <option value="">Pilih kategori</option>
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id_kategori); ?>" <?php if((string) $getValue('id_kategori') === (string) $category->id_kategori): echo 'selected'; endif; ?>><?php echo e($category->nama_kategori); ?></option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </label>
                                        <label>Label menu
                                            <input name="merk" maxlength="255" value="<?php echo e($getValue('merk')); ?>" required>
                                        </label>
                                        <label>Harga beli
                                            <input name="harga_beli" type="number" min="0" step="any" value="<?php echo e($getValue('harga_beli')); ?>" required>
                                        </label>
                                        <label>Harga jual
                                            <input name="harga_jual" type="number" min="0" step="any" value="<?php echo e($getValue('harga_jual')); ?>" required>
                                        </label>
                                        <label>Satuan
                                            <input name="satuan_barang" maxlength="255" value="<?php echo e($getValue('satuan_barang')); ?>" required>
                                        </label>
                                        <label>Stok
                                            <input name="stok" type="number" min="0" step="1" value="<?php echo e($getValue('stok', '0')); ?>" required>
                                        </label>
                                        <label class="field-wide">Foto menu (JPG, PNG, atau WebP; maks. 4 MB) <?php echo e($formAction === 'edit' ? '(kosongkan jika tidak diganti)' : ''); ?>

                                            <input name="image" type="file" accept=".jpg,.jpeg,.png,.webp,image/jpeg,image/png,image/webp" <?php if($formAction === 'create'): echo 'required'; endif; ?>>
                                        </label>
                                        <?php if($formAction === 'edit' && $editRecord->image_path): ?>
                                            <div class="field-wide">
                                                <img class="menu-preview" src="<?php echo e(asset('menu-photos/' . $editRecord->image_path)); ?>" alt="Foto <?php echo e($editRecord->nama_barang); ?>">
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                <?php elseif($page === 'kategori'): ?>
                                    <div class="form-grid form-grid-single">
                                        <label>Nama kategori
                                            <input name="nama_kategori" maxlength="255" value="<?php echo e($getValue('nama_kategori')); ?>" required>
                                        </label>
                                    </div>
                                <?php endif; ?>

                                <div class="form-actions">
                                    <a class="button button-plain" href="<?php echo e(route('merchant.dashboard', ['page' => $page])); ?>">Batal</a>
                                    <button class="button button-primary" type="submit"><?php echo e($formAction === 'edit' ? 'Simpan perubahan' : 'Simpan'); ?></button>
                                </div>
                            </form>
                        </section>
                    <?php endif; ?>

                    <section class="panel list-panel">
                        <div class="panel-heading">
                            <div>
                                <h2><?php echo e($pages[$page]); ?></h2>
                                <p><?php echo e($page === 'penjualan' ? 'Riwayat transaksi hanya dapat dilihat.' : 'Kelola data ' . mb_strtolower($pages[$page]) . '.'); ?>

                                    <?php echo e(number_format($rows->count())); ?> data ditampilkan<?php echo e($rows->count() === 100 ? ' (maksimal 100)' : ''); ?>

                                </p>
                            </div>
                        </div>
                        <?php if($rows->isNotEmpty()): ?>
                            <div class="table-wrap">
                                <table>
                                    <thead>
                                        <tr>
                                            <?php $__currentLoopData = $columns[$page]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <th><?php echo e($label); ?></th>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <?php if(in_array($page, ['barang', 'kategori'], true)): ?>
                                                <th>Aksi</th>
                                            <?php endif; ?>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php $__currentLoopData = $columns[$page]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php
                                                        $value = $row->{$key} ?? '-';
                                                        if (in_array($key, ['harga_jual', 'total'], true)) {
                                                            $value = 'Rp ' . number_format((float) $value, 0, ',', '.');
                                                        } elseif ($key === 'stok' && (int) $value <= 5) {
                                                            $value = $value . ' (menipis)';
                                                        } elseif ($key === 'is_catering_menu') {
                                                            $value = !$row->is_catering_menu
                                                                ? 'Arsip riwayat'
                                                                : ((int) $row->stok === 0 ? 'Belum tersedia' : 'Menu aktif');
                                                        }
                                                    ?>
                                                    <td class="<?php echo e(in_array($key, ['nama_barang', 'nama_kategori', 'nm_member'], true) ? 'primary-cell' : ''); ?>">
                                                        <?php if($key === 'image_path'): ?>
                                                            <?php if($row->image_path): ?>
                                                                <img class="menu-thumbnail"
                                                                     src="<?php echo e(asset('menu-photos/' . $row->image_path)); ?>"
                                                                     alt="Foto menu">
                                                            <?php else: ?>
                                                                Belum ada foto
                                                            <?php endif; ?>
                                                        <?php else: ?>
                                                            <?php echo e($value); ?>

                                                        <?php endif; ?>
                                                    </td>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(in_array($page, ['barang', 'kategori'], true)): ?>
                                                    <td class="action-cell">
                                                        <a class="table-action table-action-edit"
                                                           href="<?php echo e(route('merchant.dashboard', ['page' => $page, 'action' => 'edit', 'id' => $row->{$recordId}])); ?>">Edit</a>
                                                        <form method="POST" action="<?php echo e(route('merchant.manage')); ?>" onsubmit="return confirm('Yakin ingin menghapus data ini?');">
                                                            <?php echo csrf_field(); ?>
                                                            <input type="hidden" name="page" value="<?php echo e($page); ?>">
                                                            <input type="hidden" name="action" value="delete">
                                                            <input type="hidden" name="id" value="<?php echo e($row->{$recordId}); ?>">
                                                            <button class="table-action table-action-delete" type="submit">Hapus</button>
                                                        </form>
                                                    </td>
                                                <?php endif; ?>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                        <?php else: ?>
                            <div class="empty-state"><?php echo e($search !== '' ? 'Tidak ada data yang cocok dengan pencarian.' : 'Belum ada data untuk ditampilkan.'); ?></div>
                        <?php endif; ?>
                    </section>
                <?php endif; ?>

                <footer class="app-footer"><?php echo e(config('app.name')); ?> <span>•</span> by kensin14 (2026)</footer>
            </main>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\dashboard\index.blade.php ENDPATH**/ ?>
<?php if($paginator->hasPages()): ?>
    <nav class="market-pagination" aria-label="Navigasi halaman">
        <?php if($paginator->onFirstPage()): ?>
            <span class="market-pagination-disabled" aria-disabled="true">Sebelumnya</span>
        <?php else: ?>
            <a href="<?php echo e($paginator->previousPageUrl()); ?>" rel="prev">Sebelumnya</a>
        <?php endif; ?>

        <?php if($paginator->hasMorePages()): ?>
            <a href="<?php echo e($paginator->nextPageUrl()); ?>" rel="next">Berikutnya</a>
        <?php else: ?>
            <span class="market-pagination-disabled" aria-disabled="true">Berikutnya</span>
        <?php endif; ?>
    </nav>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\partials\pagination.blade.php ENDPATH**/ ?>
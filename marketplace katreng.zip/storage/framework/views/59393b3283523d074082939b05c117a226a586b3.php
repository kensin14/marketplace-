<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Invoice <?php echo e($invoice->invoice_number); ?> - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/marketplace.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="market-header">
        <a class="market-brand" href="<?php echo e(session('member_id') == $invoice->merchant_id ? route('merchant.dashboard') : route('customer.dashboard')); ?>">
            <span class="market-mark">MK</span><span><?php echo e(config('app.name')); ?></span>
        </a>
        <nav class="market-nav" aria-label="Navigasi invoice">
            <?php if(session('member_id') == $invoice->customer_id): ?>
                <a href="<?php echo e(route('customer.dashboard')); ?>">Dashboard</a>
            <?php endif; ?>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
        </nav>
    </header>
    <main class="market-main">
        <?php if(session('status')): ?><div class="market-notice" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
        <div class="invoice-actions">
            <a class="market-button secondary" href="<?php echo e(session('member_id') == $invoice->merchant_id ? route('merchant.orders.index') : route('customer.orders')); ?>">Kembali ke pesanan</a>
            <button class="market-button" type="button" onclick="window.print()">Cetak invoice</button>
        </div>
        <article class="invoice-card">
            <div class="invoice-top">
                <div>
                    <h1>Invoice katering</h1>
                    <div class="invoice-number"><?php echo e($invoice->invoice_number); ?></div>
                    <p>Tanggal invoice: <?php echo e($generatedAt->locale('id')->translatedFormat('j F Y, H:i')); ?></p>
                </div>
                <span class="status-pill <?php echo e($invoice->status); ?>"><?php echo e($invoice->status === 'pending' ? 'Menunggu' : ($invoice->status === 'accepted' ? 'Diterima' : 'Ditolak')); ?></span>
            </div>
            <section class="invoice-details">
                <div>
                    <h2>Katering Merchant</h2>
                    <p><strong><?php echo e($invoice->merchant_name); ?></strong></p>
                    <p><?php echo e($invoice->merchant_address); ?></p>
                    <p><?php echo e($invoice->merchant_email); ?></p>
                    <p><?php echo e($invoice->merchant_phone); ?></p>
                </div>
                <div>
                    <h2>Kantor Customer</h2>
                    <p><strong><?php echo e($invoice->customer_name); ?></strong></p>
                    <p><?php echo e($invoice->delivery_address); ?></p>
                    <p><?php echo e($invoice->customer_email); ?></p>
                    <p>Tanggal pengiriman: <?php echo e(\Illuminate\Support\Carbon::parse($invoice->delivery_date)->locale('id')->translatedFormat('j F Y')); ?></p>
                </div>
            </section>
            <div class="table-scroll">
                <table class="market-table">
                    <thead><tr><th>Menu</th><th>Harga satuan</th><th>Jumlah</th><th>Total</th></tr></thead>
                    <tbody>
                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->product_name); ?></td>
                                <td>Rp <?php echo e(number_format((float) $item->unit_price, 0, ',', '.')); ?></td>
                                <td><?php echo e($item->quantity); ?></td>
                                <td>Rp <?php echo e(number_format((float) $item->line_total, 0, ',', '.')); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <?php if($invoice->notes): ?><p class="muted">Catatan: <?php echo e($invoice->notes); ?></p><?php endif; ?>
            <div class="invoice-total">Total: Rp <?php echo e(number_format((float) $invoice->subtotal, 0, ',', '.')); ?></div>
        </article>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\orders\invoice.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Cari katering - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/marketplace.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="market-header">
        <a class="market-brand" href="<?php echo e(route('customer.dashboard')); ?>">
            <span class="market-mark">MK</span><span><?php echo e(config('app.name')); ?></span>
        </a>
        <nav class="market-nav" aria-label="Navigasi customer">
            <a href="<?php echo e(route('customer.dashboard')); ?>">Dashboard</a>
            <a class="active" href="<?php echo e(route('customer.catalog')); ?>">Cari menu</a>
            <a href="<?php echo e(route('customer.orders')); ?>">Pesanan</a>
            <a href="<?php echo e(route('customer.cart')); ?>">Keranjang (<?php echo e($cartCount); ?>)</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
        </nav>
    </header>
    <main class="market-main">
        <section class="market-heading">
            <h1>Temukan katering untuk kantor</h1>
            <p>Cari menu berdasarkan nama, jenis makanan, atau lokasi katering.</p>
        </section>

        <?php if(session('status')): ?>
            <div class="market-notice" role="status"><?php echo e(session('status')); ?></div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="market-notice error" role="alert"><?php echo e($errors->first()); ?></div>
        <?php endif; ?>

        <?php echo $__env->make('customer.partials.catalog-products', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\customer\catalog.blade.php ENDPATH**/ ?>
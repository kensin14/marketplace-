<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesanan katering - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/marketplace.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="market-header">
        <a class="market-brand" href="<?php echo e(route('merchant.dashboard')); ?>"><span class="market-mark">MK</span><span><?php echo e(config('app.name')); ?></span></a>
        <nav class="market-nav" aria-label="Navigasi merchant">
            <a href="<?php echo e(route('merchant.dashboard')); ?>">Dashboard</a>
            <a class="active" href="<?php echo e(route('merchant.orders.index')); ?>">Pesanan katering</a>
            <a href="<?php echo e(route('merchant.profile.edit')); ?>">Profil katering</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
        </nav>
    </header>
    <main class="market-main">
        <section class="market-heading"><h1>Pesanan katering</h1><p>Kelola pesanan yang dibuat oleh kantor customer.</p></section>
        <?php if(session('status')): ?><div class="market-notice" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?><div class="market-notice error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>
        <?php if($orders->isNotEmpty()): ?>
            <section class="order-list">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="order-card">
                        <div>
                            <h2><?php echo e($order->customer_name); ?> <span class="status-pill <?php echo e($order->status); ?>"><?php echo e($order->status === 'pending' ? 'Menunggu' : ($order->status === 'accepted' ? 'Diterima' : 'Ditolak')); ?></span></h2>
                            <div class="order-meta">
                                <span><?php echo e($order->invoice_number); ?></span>
                                <span>Kirim <?php echo e(\Illuminate\Support\Carbon::parse($order->delivery_date)->locale('id')->translatedFormat('j F Y')); ?></span>
                                <span><?php echo e($order->delivery_address); ?></span>
                                <span>Rp <?php echo e(number_format((float) $order->subtotal, 0, ',', '.')); ?></span>
                            </div>
                            <?php if($order->notes): ?><p class="muted">Catatan: <?php echo e($order->notes); ?></p><?php endif; ?>
                        </div>
                        <div class="table-actions">
                            <a class="market-button secondary" href="<?php echo e(route('merchant.orders.invoice', $order->id)); ?>">Invoice</a>
                            <?php if($order->status === 'pending'): ?>
                                <form method="POST" action="<?php echo e(route('merchant.orders.status', $order->id)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="accepted">
                                    <button class="market-button" type="submit">Terima</button>
                                </form>
                                <form method="POST" action="<?php echo e(route('merchant.orders.status', $order->id)); ?>">
                                    <?php echo csrf_field(); ?> <?php echo method_field('PATCH'); ?>
                                    <input type="hidden" name="status" value="rejected">
                                    <button class="market-button danger" type="submit">Tolak</button>
                                </form>
                            <?php endif; ?>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <?php echo $__env->make('partials.pagination', ['paginator' => $orders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <section class="market-panel market-empty">Belum ada pesanan masuk.</section>
        <?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\merchant\orders.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Daftar - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/auth.css')); ?>" rel="stylesheet">
</head>
<body>
    <main class="auth-page">
        <section class="auth-card" aria-labelledby="register-title">
            <div class="auth-brand">
                <div class="brand-mark" aria-hidden="true">MK</div>
                <p class="eyebrow">MULAI SEKARANG</p>
                <h1 id="register-title">Buat akun</h1>
                <p class="auth-description">Daftar untuk mulai menggunakan <?php echo e(config('app.name')); ?>.</p>
            </div>

            <?php if($errors->any()): ?>
                <div class="form-message form-message-error" role="alert"><?php echo e($errors->first()); ?></div>
            <?php endif; ?>

            <form method="POST" action="<?php echo e(route('register.store')); ?>">
                <?php echo csrf_field(); ?>
                <label for="name">Nama kantor atau perusahaan katering</label>
                <input id="name" type="text" name="name" placeholder="Nama kantor / katering" maxlength="255"
                    autocomplete="name" value="<?php echo e(old('name')); ?>" required autofocus>

                <label for="user">Username</label>
                <input id="user" type="text" name="user" placeholder="Buat username" maxlength="255"
                    autocomplete="username" value="<?php echo e(old('user')); ?>" required>

                <label for="email">Email</label>
                <input id="email" type="email" name="email" placeholder="nama@email.com" maxlength="255"
                    autocomplete="email" value="<?php echo e(old('email')); ?>" required>

                <label for="telepon">Nomor kontak</label>
                <input id="telepon" type="tel" name="telepon" placeholder="Nomor telepon/WhatsApp" maxlength="255"
                    autocomplete="tel" value="<?php echo e(old('telepon')); ?>">

                <label for="description">Deskripsi katering (khusus merchant)</label>
                <textarea id="description" name="description" rows="3" maxlength="2000"
                    placeholder="Ceritakan layanan katering Anda"><?php echo e(old('description')); ?></textarea>

                <label for="alamat_member">Alamat</label>
                <textarea id="alamat_member" name="alamat_member" rows="3" maxlength="1000"
                    autocomplete="street-address" required><?php echo e(old('alamat_member')); ?></textarea>

                <label for="role">Daftar sebagai</label>
                <select id="role" name="role" required>
                    <option value="">Pilih jenis akun</option>
                    <option value="merchant" <?php if(old('role') === 'merchant'): echo 'selected'; endif; ?>>Katering Merchant</option>
                    <option value="customer" <?php if(old('role') === 'customer'): echo 'selected'; endif; ?>>Kantor Customer</option>
                </select>

                <label for="pass">Password</label>
                <input id="pass" type="password" name="pass" placeholder="Minimal 6 karakter"
                    minlength="6" autocomplete="new-password" required>

                <label for="confirm_pass">Konfirmasi password</label>
                <input id="confirm_pass" type="password" name="confirm_pass" placeholder="Ulangi password"
                    minlength="6" autocomplete="new-password" required>

                <button class="auth-button" type="submit">Daftar</button>
            </form>

            <p class="auth-footer">Sudah punya akun? <a href="<?php echo e(route('login')); ?>">Masuk</a></p>
        </section>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\auth\register.blade.php ENDPATH**/ ?>
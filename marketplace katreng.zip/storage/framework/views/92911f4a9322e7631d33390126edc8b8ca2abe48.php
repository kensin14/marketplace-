<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Keranjang - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/marketplace.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="market-header">
        <a class="market-brand" href="<?php echo e(route('customer.dashboard')); ?>"><span class="market-mark">MK</span><span><?php echo e(config('app.name')); ?></span></a>
        <nav class="market-nav" aria-label="Navigasi customer">
            <a href="<?php echo e(route('customer.dashboard')); ?>">Dashboard</a>
            <a href="<?php echo e(route('customer.catalog')); ?>">Cari menu</a>
            <a href="<?php echo e(route('customer.orders')); ?>">Pesanan</a>
            <a class="active" href="<?php echo e(route('customer.cart')); ?>">Keranjang (<?php echo e($cartCount); ?>)</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
        </nav>
    </header>
    <main class="market-main">
        <section class="market-heading"><h1>Keranjang pesanan</h1><p>Periksa menu dari satu atau beberapa merchant dan jadwalkan pengiriman untuk kantor Anda. Setiap merchant menerima pesanan dan invoice terpisah.</p></section>
        <?php if(session('status')): ?><div class="market-notice" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
        <?php if($errors->any()): ?><div class="market-notice error" role="alert"><?php echo e($errors->first()); ?></div><?php endif; ?>

        <?php if($products->isEmpty()): ?>
            <section class="market-panel market-empty">
                Keranjang masih kosong. <a href="<?php echo e(route('customer.catalog')); ?>"><strong>Cari menu katering</strong></a>
            </section>
        <?php else: ?>
            <?php $__currentLoopData = $merchantGroups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $merchantProducts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php ($merchant = $merchantProducts->first()); ?>
                <section class="market-panel">
                    <h2><?php echo e($merchant->merchant_name); ?></h2>
                    <p class="muted"><?php echo e($merchant->merchant_address); ?></p>
                    <div class="table-scroll">
                        <table class="market-table">
                            <thead><tr><th>Menu</th><th>Harga</th><th>Jumlah</th><th>Subtotal</th><th></th></tr></thead>
                            <tbody>
                                <?php $__currentLoopData = $merchantProducts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($product->nama_barang); ?></td>
                                        <td>Rp <?php echo e(number_format((float) $product->harga_jual, 0, ',', '.')); ?></td>
                                        <td><?php echo e($product->quantity); ?> <?php echo e($product->satuan_barang); ?></td>
                                        <td>Rp <?php echo e(number_format($product->line_total, 0, ',', '.')); ?></td>
                                        <td>
                                            <form method="POST" action="<?php echo e(route('customer.cart.remove', $product->id)); ?>">
                                                <?php echo csrf_field(); ?> <?php echo method_field('DELETE'); ?>
                                                <button class="market-button danger" type="submit">Hapus</button>
                                            </form>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    <div class="cart-total"><span>Subtotal merchant</span><span>Rp <?php echo e(number_format($merchantProducts->sum('line_total'), 0, ',', '.')); ?></span></div>
                </section>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <section class="market-panel">
                <div class="cart-total"><span>Total seluruh pesanan</span><span>Rp <?php echo e(number_format($subtotal, 0, ',', '.')); ?></span></div>
            </section>

            <form class="market-panel checkout-grid" method="POST" action="<?php echo e(route('customer.checkout')); ?>">
                <?php echo csrf_field(); ?>
                <label class="market-field">Tanggal pengiriman
                    <input name="delivery_date" type="date" min="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(old('delivery_date')); ?>" required>
                </label>
                <label class="market-field">Alamat pengiriman
                    <input name="delivery_address" maxlength="1000" value="<?php echo e(old('delivery_address', $customer->alamat_member ?? '')); ?>" required>
                </label>
                <label class="market-field field-wide">Catatan untuk katering
                    <textarea name="notes" maxlength="2000" placeholder="Contoh: antar sebelum jam makan siang"><?php echo e(old('notes')); ?></textarea>
                </label>
                <div class="field-wide"><button class="market-button" type="submit">Checkout ke <?php echo e($merchantGroups->count()); ?> merchant</button></div>
            </form>
        <?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\customer\cart.blade.php ENDPATH**/ ?>
<form class="market-panel filter-grid" method="GET" action="<?php echo e(route($searchRoute)); ?>">
    <label class="market-field">Menu atau katering
        <input name="q" type="search" value="<?php echo e($filters['q']); ?>" placeholder="Contoh: nasi ayam">
    </label>
    <label class="market-field">Lokasi
        <input name="location" value="<?php echo e($filters['location']); ?>" placeholder="Kota atau alamat">
    </label>
    <label class="market-field">Jenis makanan
        <select name="category">
            <option value="">Semua jenis</option>
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($category->id_kategori); ?>" <?php if($filters['category'] === (string) $category->id_kategori): echo 'selected'; endif; ?>>
                    <?php echo e($category->nama_kategori); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </label>
    <button class="market-button" type="submit">Cari katering</button>
</form>

<?php if($products->isNotEmpty()): ?>
    <section class="product-grid" aria-label="Daftar menu katering">
        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <article class="product-card">
                <?php if($product->image_path): ?>
                    <img class="product-image" src="<?php echo e(asset('menu-photos/' . $product->image_path)); ?>"
                         alt="Foto <?php echo e($product->nama_barang); ?>" loading="lazy">
                <?php else: ?>
                    <div class="product-image-placeholder" aria-label="Foto menu belum tersedia">
                        <strong><?php echo e($product->nama_barang); ?></strong>
                        <span>Foto menu akan ditambahkan katering</span>
                    </div>
                <?php endif; ?>
                <span class="product-category"><?php echo e($product->nama_kategori ?? 'Menu katering'); ?></span>
                <h2><?php echo e($product->nama_barang); ?></h2>
                <p class="product-merchant"><?php echo e($product->merchant_name); ?></p>
                <p class="product-location"><?php echo e($product->merchant_location); ?></p>
                <?php if($product->merchant_description): ?><p class="product-description"><?php echo e($product->merchant_description); ?></p><?php endif; ?>
                <?php if($product->menu_description && !str_starts_with($product->menu_description, 'DRAF MENU.')): ?>
                    <p class="product-description"><?php echo e($product->menu_description); ?></p>
                <?php endif; ?>
                <?php if((int) $product->stok > 0): ?>
                    <p class="product-stock">Tersedia <?php echo e($product->stok); ?> <?php echo e($product->satuan_barang); ?></p>
                <?php else: ?>
                    <p class="product-stock">Belum tersedia. Katering sedang menyiapkan stok.</p>
                <?php endif; ?>
                <div class="product-bottom">
                    <div class="product-price">Rp <?php echo e(number_format((float) $product->harga_jual, 0, ',', '.')); ?>

                        <small>per <?php echo e($product->satuan_barang); ?></small>
                    </div>
                    <?php if((int) $product->stok > 0): ?>
                        <form class="add-form" method="POST" action="<?php echo e(route('customer.cart.add')); ?>">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">
                            <label class="visually-hidden" for="quantity-<?php echo e($product->id); ?>">Jumlah porsi</label>
                            <input id="quantity-<?php echo e($product->id); ?>" name="quantity" type="number" min="1"
                                max="<?php echo e($product->stok); ?>" value="1" aria-label="Jumlah porsi" required>
                            <button class="market-button" type="submit">Tambah</button>
                        </form>
                    <?php else: ?>
                        <button class="market-button" type="button" disabled>Belum tersedia</button>
                    <?php endif; ?>
                </div>
            </article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </section>
<?php else: ?>
    <div class="market-panel market-empty">Belum ada menu yang cocok. Coba ubah kata kunci, kategori, atau lokasi.</div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\customer\partials\catalog-products.blade.php ENDPATH**/ ?>
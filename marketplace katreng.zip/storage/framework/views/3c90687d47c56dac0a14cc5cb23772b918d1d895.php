<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Pesanan saya - <?php echo e(config('app.name')); ?></title>
    <link href="<?php echo e(asset('css/marketplace.css')); ?>" rel="stylesheet">
</head>
<body>
    <header class="market-header">
        <a class="market-brand" href="<?php echo e(route('customer.dashboard')); ?>"><span class="market-mark">MK</span><span><?php echo e(config('app.name')); ?></span></a>
        <nav class="market-nav" aria-label="Navigasi customer">
            <a href="<?php echo e(route('customer.dashboard')); ?>">Dashboard</a>
            <a href="<?php echo e(route('customer.catalog')); ?>">Cari menu</a>
            <a class="active" href="<?php echo e(route('customer.orders')); ?>">Pesanan</a>
            <a href="<?php echo e(route('customer.cart')); ?>">Keranjang (<?php echo e($cartCount); ?>)</a>
            <form method="POST" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit">Keluar</button></form>
        </nav>
    </header>
    <main class="market-main">
        <section class="market-heading"><h1>Pesanan kantor</h1><p>Riwayat dan status pesanan katering Anda.</p></section>
        <?php if(session('status')): ?><div class="market-notice" role="status"><?php echo e(session('status')); ?></div><?php endif; ?>
        <?php if($orders->isNotEmpty()): ?>
            <section class="order-list">
                <?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <article class="order-card">
                        <div>
                            <h2><?php echo e($order->merchant_name); ?></h2>
                            <div class="order-meta">
                                <span><?php echo e($order->invoice_number); ?></span>
                                <span>Kirim <?php echo e(\Illuminate\Support\Carbon::parse($order->delivery_date)->locale('id')->translatedFormat('j F Y')); ?></span>
                                <span>Rp <?php echo e(number_format((float) $order->subtotal, 0, ',', '.')); ?></span>
                            </div>
                        </div>
                        <div class="table-actions">
                            <span class="status-pill <?php echo e($order->status); ?>"><?php echo e($order->status === 'pending' ? 'Menunggu' : ($order->status === 'accepted' ? 'Diterima' : 'Ditolak')); ?></span>
                            <a class="market-button secondary" href="<?php echo e(route('customer.orders.invoice', $order->id)); ?>">Lihat invoice</a>
                        </div>
                    </article>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <?php echo $__env->make('partials.pagination', ['paginator' => $orders], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php else: ?>
            <section class="market-panel market-empty">Belum ada pesanan. <a href="<?php echo e(route('customer.catalog')); ?>"><strong>Jelajahi menu katering</strong></a></section>
        <?php endif; ?>
    </main>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\marketplace katreng\resources\views\customer\orders.blade.php ENDPATH**/ ?>